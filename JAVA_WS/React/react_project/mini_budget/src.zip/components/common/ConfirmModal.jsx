// src/components/common/ConfirmModal.jsx
import React from "react";
import "./ConfirmModal.css"; // ConfirmModal 컴포넌트 전용 CSS 파일 임포트

/**
 * 사용자에게 특정 작업(예: 삭제)에 대한 확인을 요청하는 모달 컴포넌트입니다.
 * @param {{
 * isOpen: boolean, // 모달의 열림/닫힘 상태
 * message: string, // 모달에 표시할 메시지
 * onConfirm: () => void, // '확인' 버튼 클릭 시 호출될 함수
 * onCancel: () => void // '취소' 버튼 클릭 시 호출될 함수
 * }} props
 */
const ConfirmModal = ({ isOpen, message, onConfirm, onCancel }) => {
  // 모달이 DOM에서 제거되지 않고, CSS 트랜지션이 부드럽게 작동하도록
  // isOpen 값에 따라 'open' 클래스를 동적으로 추가하여 CSS로 모달의 표시 여부를 제어합니다.
  // 이전에 'if (!isOpen) return null;' 코드가 있었으나, 이를 제거하여 항상 렌더링되도록 변경했습니다.
  return (
    // 모달 오버레이: 화면 전체를 덮고 배경을 어둡게 처리
    // isOpen 값에 따라 'open' 클래스를 동적으로 추가합니다.
    <div className={`modal-overlay ${isOpen ? "open" : ""}`} onClick={onCancel}>
      {/* 모달 내용 컨테이너: 클릭 이벤트 전파 방지 */}
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <p className="modal-message">{message}</p>
        <div className="modal-actions">
          <button onClick={onCancel} className="modal-button cancel">
            취소
          </button>
          <button onClick={onConfirm} className="modal-button confirm">
            확인
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmModal;
