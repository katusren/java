/* src/components/layout/footer/Footer.jsx */

import React from "react";
import { Link, useLocation } from "react-router-dom";
import "./Footer.css";

const Footer = () => {
  const location = useLocation();

  return (
    <footer className="app-footer">
      <nav className="footer-nav">
        {/* 홈 링크 */}
        <Link
          to="/"
          className={`nav-item ${location.pathname === "/" ? "active" : ""}`}
        >
          <span className="nav-icon">🏠</span>
          <span className="nav-text">홈</span>
        </Link>
        {/* 등록 링크 */}
        <Link
          to="/add"
          className={`nav-item ${location.pathname === "/add" ? "active" : ""}`}
        >
          <span className="nav-icon">➕</span>
          <span className="nav-text">등록</span>
        </Link>
        {/* 달력 링크 */}
        <Link
          to="/statistics"
          className={`nav-item ${
            location.pathname === "/statistics" ? "active" : ""
          }`}
        >
          <span className="nav-icon">📊</span>
          <span className="nav-text">통계</span>
        </Link>
        {/* 설정 링크 */}
        <Link
          to="/settings"
          className={`nav-item ${
            location.pathname === "/settings" ? "active" : ""
          }`}
        >
          <span className="nav-icon">⚙️</span>
          <span className="nav-text">설정</span>
        </Link>
      </nav>
    </footer>
  );
};

export default Footer;
