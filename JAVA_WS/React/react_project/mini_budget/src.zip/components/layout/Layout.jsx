/* src/components/layout/Layout.jsx */

import React from "react";
import Header from "./header/Header"; // Header 컴포넌트 임포트
import Footer from "./footer/Footer"; // Footer 컴포넌트 임포트
import "./Layout.css";

const Layout = ({ children }) => {
  return (
    <div className="layout-container">
      {/* 상단 헤더 */}
      <Header />

      <main className="main-content">{children}</main>

      {/* 하단 푸터 */}
      <Footer />
    </div>
  );
};

export default Layout;
